# Concrete Video & Research Evidence Handoff for Grok (`02-grok`)

- **Upstream Reviewer**: Gemini (`01-gemini`)
- **Reviewed Core Input Fingerprint**: `f489b98968357041fb117cd564d0fe02d0e2acc0343756ae430b85b03765909d` (commit `a4205bbdbab74c8d4b646f506850981128f41472`, reconciled from `ea19cbb47577219582541f41789480d7c782f6ffa68aaa9537f3f5e7f336ba7a` / `0f45886549517609ffcd150c770d9cecb55d9ad4`)
- **Reviewed Supplementary Intake Fingerprint (`external_fingerprint`)**: `1155023d21cdddb6ca83690e6540273cb53d622ef6c1c7b2a24a908d5f663854`

## 1. Strongest Video Demonstrations to Preserve & Complement
1. **Multimodal Pitch & Sycophancy Contrast (`YT-01`, `ujFqaZSguto` `00:00–01:21`, `video_0` + transcript)**: Separates Custom Instruction sycophancy ("be extra friendly") from RLHF thumbs-up sycophancy (`C04`, `C05`).
2. **Spoken Turn Length & Live Interruption UI (`YT-02`, `v-EYzZCLF48` `00:40–01:27`, `video_0` + transcript)**: Demonstrates 1–2 sentence spoken turn budgets (`00:49–00:52`) paired with live interruption (`00:40–00:42`).
3. **Psychological Security vs. Criticism Spirals (`YT-05`, `I9aGC6Ui3eE` `00:06:28–00:08:58`, `00:23:25–00:24:45`)**: Explains why models collapse into defensive apologies under correction (`C02`, `C14`) or pathologize normal user fatigue when over-indexing on safety reminders (`C06`, `C08`).
4. **Longitudinal Prompt Bloat Audit (`YT-07`, `yoh8v3GtxLg` `00:00:45–00:12:48`) & Checklist Narration Leakage (`YT-08`, `ysPbXH0LpIE` `00:18:50–00:19:30`)**: Shows why reactive negative rules must be replaced by compact positive decision hinges and silent fast-path execution.
5. **CoALA 4-Tier Progressive Disclosure (`YT-10`, `BacJ6sEhqMo` `00:01:47–00:06:30`) & Markdown Memory Consolidation (`YT-11`, `Seu7nksZ_4k` `00:03:28–00:07:16`)**: Grounds our separation of `native_compact` (`1344` chars) / `native_extended` (`3374` chars) from the on-demand `C01–C18` contrast bank.
6. **Sophisticated Sycophancy & the 1.8% Persona Lock-In Counterevidence (`YT-12`, `itxNEvEho9s` `00:01:15–00:04:45`)**: Grounds `C16` and `C18`.
7. **Live Voice Barge-In & Dead-Air Failures (`YT-13`, `ES3HhoYCtIc` `00:03:18–00:04:45` & `Ky2Z6kGp1Vk` `00:07:55–00:08:58`)**: Grounds `C17`, STT homophone verification, and pre-tool vocal signposting.
8. **LLM-as-a-Judge Variance ($SD=0.63$), AB/BA Position Flip Ties, & Cohen's $\kappa$ Calibration (`YT-04`, `iZOOYwfK0Qo` & `YT-14`, `OTu6xZUKK2U` `00:02:48–00:08:45`, `t-tR9lqG_ok` `00:05:02–00:07:18`)**: Grounds `GEM-005`.

## 2. Unresolved Questions & Conflicting Evidence for Grok's X/Twitter & Implementation Audit
1. **Weight-Level Character Training (`YT-05`) vs. 1,500-Char Runtime Prompt Steering (`YT-07`/`YT-13`)**: Investigate via X/Twitter practitioner threads and multi-turn stress tests which of Lucifer's 7 first-principle hinges hold across 20+ turns under a 1,500-char (`native_compact`) budget without weight fine-tuning, and where RLHF sycophancy priors resurface.
2. **Hard Persona Guardrails (`YT-12` 1.8% Lock-In) vs. Over-Triggering Safety Reminders (`YT-05` `00:23:25`)**: Stress-test `C18` against ambiguous late-night tiredness vs. genuine emergencies so Lucifer releases fictional framing immediately on real emergencies without pathologizing normal exhaustion.
3. **Russian Feminine Past-Tense Stability in Heavy Bilingual Code Sessions**: Check X/Twitter reports and test whether the compact Russian feminine anchors (`«я решила»`, `«я проверила»`, `«я ошиблась»`) in `native_compact` / `native_extended` prevent masculine verb drift (`«я сделал»`) after 10+ turns of English stack traces.
4. **Live Voice Barge-In Latency vs. High Reasoning Effort**: Audit `install/control-catalog.json` to ensure high reasoning effort is restricted to asynchronous text/engineering sessions and never forced onto real-time voice sessions where thinking tokens add multi-second latency.
