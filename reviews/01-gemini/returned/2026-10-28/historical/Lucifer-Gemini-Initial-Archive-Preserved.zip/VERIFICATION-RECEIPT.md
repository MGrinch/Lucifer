# Verification Results & Untested Boundaries Receipt (`01-gemini`)

## 1. Checks Actually Executed & Passed in Sandbox VM (`execute_bash`)

1. **68-File Core Input Manifest Cryptographic Verification (`PASS`)**:
   - Verified `reviews/01-gemini/input-manifest.json` (`68` files) against `sha256-path-hash-json-v1` fingerprint `f489b98968357041fb117cd564d0fe02d0e2acc0343756ae430b85b03765909d` (reconciled from initial pass `ea19cbb47577219582541f41789480d7c782f6ffa68aaa9537f3f5e7f336ba7a`).
2. **Core & Supplementary Read Coverage Gate (`PASS`)**:
   - Executed `validate_file_read_coverage` and `validate_external_coverage` from `tools/lucifer.py` (commit `a4205bbdbab74c8d4b646f506850981128f41472`) against `reviews/01-gemini/read-coverage.json` (`68` files, contiguous ranges `[[1, lines]]`) and `reviews/01-gemini/supplementary-coverage.json` (`3` files, `external_fingerprint`: `1155023d21cdddb6ca83690e6540273cb53d622ef6c1c7b2a24a908d5f663854`, matching `review.json.attestation.supplementary_fingerprint`).
3. **Runtime Payload Fence & Character/UTF-16 Budget Check (`PASS`)**:
   - Executed `fenced_block()` and `derived()` length checks from `tools/lucifer.py`:
     - Existing unpatched `native_compact`: `510` chars / `510` UTF-16 units (`<= 1,500`).
     - Proposed `native_compact`: **`1344` chars / `1344` UTF-16 units** (`1370` bytes, SHA-256 `00beb01918b4683e7473f761209f1645db00aaa0e65557eed09f7cb9ab22bc3e`, `<= 1,500`).
     - Existing unpatched `native_extended`: `1645` chars / `1645` UTF-16 units (`<= 5,000`).
     - Proposed `native_extended`: **`3374` chars / `3374` UTF-16 units** (`3546` bytes, SHA-256 `39061a8073bad13a0acd85f84f17da48dec2b4e39754bbc2b907d53a550ddb01`, `<= 5,000`).
4. **Post-Apply `validate_round` Simulation (`PASS`)**:
   - Verified that when `patches/integration-after-apply-template.json` (`status: "integrated"`) is paired with the delivered `review.json`, `input-manifest.json`, `read-coverage.json`, `supplementary-coverage.json`, `report.md`, `findings.json`, and `sources.json`, `validate_round(root, "01-gemini", "Gemini")` passes with **0 errors**.

## 2. Skips, Limitations & Untested Boundaries Preserved Honestly

1. **No Direct GitHub Commit/Push (`SKIPPED / READ_ONLY_HOST`)**:
   - `write_capability_observed: false`. The sandbox VM has no outbound network access and the browser tool is unauthenticated on GitHub. All patches are unapplied proposals; `reviews/01-gemini/integration.json` is left at `"status": "pending"` and `reviews/01-gemini/publication.json` is left at `"status": "NOT_STARTED"` (`"pushed": false`).
2. **Outer UI Model Selector String (`UNKNOWN_IN_SANDBOX`)**:
   - The sandbox runtime exposes `service_observed: "Gemini"` and developer header `EFFORT LEVEL: 0.25`, but does not expose the outer UI model version string (`"Gemini 4 Argon"`). Recorded as `model_observed: null` (`unknown_in_sandbox` in `runtime_evidence`) without fabrication.
3. **Long-Form Video Audio/Video Modality Cap (`PARTIAL_MODALITY_LIMITATION`)**:
   - Videos `YT-01` through `YT-04` (`<= 2.5` minutes) were inspected with full multimodal `video_0` audio/video streams + transcripts. Longer videos `YT-05` through `YT-14` (`5–37` minutes) returned full timestamped transcripts only (`timestamped_transcript_only`); heard delivery claims are never made from transcript-only sources.
4. **Live Model Behavioral & Acoustic Trials (`NOT_RUN`)**:
   - `runtime_validation` and `acoustic_validation` in `workflow/state.json` remain `NOT_RUN`. Proposed prompt edits and statistical thresholds (`alpha = 0.025`, `delta_0 = 0.15`, `Delta_reg = -0.05`, `kappa >= 0.60`) are unvalidated engineering proposals until live paired trials and human calibration are executed after both reviews complete.
